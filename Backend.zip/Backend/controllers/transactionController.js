// controllers/transactionController.js
const mongoose = require('mongoose');
const Expense = require('../models/Expense');

exports.getRecentTransactions = async (req, res) => {
    try {
        // Validate user ID
        const userId = req.params.userId;
        if (!mongoose.Types.ObjectId.isValid(userId)) {
            return res.status(400).json({ message: 'Invalid user ID' });
        }

        const limit = parseInt(req.query.limit) || 5; // Default to 5 transactions
        const transactions = await Expense.find({ userId }).sort({ date: -1 }).limit(limit);
        res.status(200).json(transactions);
    } catch (error) {
        console.error('Error fetching recent transactions:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

const mongoose = require('mongoose');
const Expense = require('../models/Expense');
const User = require('../models/User'); // Ensure you have the User model to fetch the user's income

exports.getOverviewData = async (req, res) => {
    try {
        const { userId } = req.params;

        // Validate if userId is a valid ObjectId
        if (!mongoose.Types.ObjectId.isValid(userId)) {
            return res.status(400).json({ message: 'Invalid user ID' });
        }

        // Convert userId to ObjectId for MongoDB queries using 'new' keyword
        const userObjectId = new mongoose.Types.ObjectId(userId);

        // Aggregate data for total expenses
        const expenses = await Expense.aggregate([
            { $match: { userId: userObjectId } }, // Match documents with the specified userId
            {
                $group: {
                    _id: '$userId',
                    totalExpenses: { $sum: '$amount' } // Summing up all expenses
                }
            }
        ]);

        const totalExpenses = expenses[0]?.totalExpenses || 0;

        // Fetch user's income
        const user = await User.findById(userId);
        const totalIncome = user?.income || 0;

        const balance = totalIncome - totalExpenses;

        res.json({
            totalExpenses,
            totalIncome,
            balance
        });
    } catch (error) {
        console.error('Error fetching overview data:', error);
        res.status(500).json({ message: 'Server error' });
    }
};

const Expense = require('../models/Expense');
const mongoose = require('mongoose');

exports.getDashboardData = async (req, res) => {
    try {
        const { userId } = req.params;

        // Validate if userId is provided and a valid ObjectId
        if (!userId || !mongoose.Types.ObjectId.isValid(userId)) {
            return res.status(400).json({ message: 'Valid user ID is required' });
        }

        // Convert userId to ObjectId for MongoDB queries
        const userObjectId = new mongoose.Types.ObjectId(userId);

        // Aggregate data for expenses by category
        const categoryAggregation = await Expense.aggregate([
            { $match: { userId: userObjectId } },
            {
                $group: {
                    _id: '$category',
                    totalAmount: { $sum: '$amount' },
                },
            },
        ]);

        // Aggregate data for expenses by month
        const monthlyAggregation = await Expense.aggregate([
            { $match: { userId: userObjectId } },
            {
                $group: {
                    _id: { $month: '$date' },
                    totalAmount: { $sum: '$amount' },
                },
            },
            { $sort: { '_id': 1 } }, // Sort by month (ascending order)
        ]);

        // Respond with the aggregated data
        res.status(200).json({
            categoryData: categoryAggregation,
            monthlyData: monthlyAggregation,
        });
    } catch (error) {
        console.error('Error fetching dashboard data:', error);
        res.status(500).json({ message: 'Server error' });
    }
};
